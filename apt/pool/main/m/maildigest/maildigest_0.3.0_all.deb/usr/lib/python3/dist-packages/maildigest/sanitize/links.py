"""Link-Erkennung und -Defanging: URLs (auch obfuskiert) durch ``[Link #n: domain.tld]``
ersetzen; ``mailto:``/``tel:`` analog; Punycode-Domains kennzeichnen.

Politik: docs/SECURITY.md §4 (I3, T3, T12). Umsetzung in WP3 (Details: ADR-028).

Erkennungs-Pässe (in dieser Reihenfolge, jeweils Ersetzung durch einen Platzhalter,
damit spätere Pässe nicht auf die eingesetzten Marker anspringen):

1. URLs mit (auch obfuskiertem) Schema: ``http``, ``https``, ``hxxp``, ``h t t p``,
   ``%68ttp`` …, plus ``ftp``/``ftps``.
2. ``mailto:``-Adressen.
3. ``tel:``-Nummern.
4. ``www.``-Domains ohne Schema.
5. Domains mit obfuskierten Punkten: ``example(.)com``, ``example[.]com``, ``(dot)``.
6. Nackte Klartext-Domains (``example.com``) — nur mit eng gesetzten Punkten und
   alphabetischer TLD; bekannte Datei-Endungen werden übersprungen (ADR-028).

Der aufrufende Code muss den Text vorher durch
:func:`maildigest.sanitize.unicode_clean.clean_text` schicken: Zero-Width-Zeichen im
Wort ``http`` würden die Erkennung sonst aushebeln, und die intern verwendeten
``\\x00``-Platzhalter setzen voraus, dass der Eingabetext keine NUL-Bytes enthält.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field
from urllib.parse import unquote

from maildigest.sanitize.unicode_clean import clean_text, is_mixed_script_domain

__all__ = [
    "CAPPED_MARKER",
    "FOOTNOTE_TITLE",
    "MAX_LINKS_PER_MAIL",
    "LinkCollector",
    "build_footnote",
]

#: Obergrenze der in `links_found` gesammelten Einträge (Schutz vor Link-Bomben, T10).
_MAX_LINKS_LISTED = 100

#: Obergrenze der Funde, die **eine Mail** überhaupt einzeln auswerten darf (T10, R-5).
#:
#: Ohne dieses Budget wächst die Arbeit je Mail mit der Zahl der Links: Rück-Ersetzung,
#: Punycode-Prüfung und Marker-Bau kosten je Fund. Eine Mail mit 41 000 Links lag damit
#: deutlich über der 10-s-Zusage (SPEC-CLI §5). Jenseits des Budgets überlebt **keine**
#: URL (I3): Der Fund wird durch :data:`CAPPED_MARKER` ersetzt und in `links_removed`
#: weitergezählt, bekommt aber weder eine Nummer in der Fußnote noch eine Domain-Analyse.
#: Modulkonstante wie `MAX_HTML_PARTS`: keine Betriebsgrösse, sondern eine
#: Struktur-Plausibilität — echte Mail bleibt um Grössenordnungen darunter.
MAX_LINKS_PER_MAIL = 2000

#: Ersatz für einen Fund jenseits von :data:`MAX_LINKS_PER_MAIL` (R-5). Trägt bewusst
#: weder Host noch Nummer — er ist nur der Nachweis, dass hier etwas entfernt wurde.
CAPPED_MARKER = "[Link removed]"

#: Zeichenbudget der optionalen Link-Fußnote — eine Link-Bombe sprengt sie nicht (T10).
_MAX_FOOTNOTE_CHARS = 5000

#: Überschrift der Fußnote. Öffentlich, damit Tests und Composer denselben Wortlaut sehen.
FOOTNOTE_TITLE = "Link footnote (defanged):"

#: Obergrenze der Länge einer defangten URL in `links_found`.
_MAX_DEFANGED_CHARS = 300

# --- Regex-Bausteine -----------------------------------------------------------------------

#: Obfuskierter Punkt: (.) [.] {.} (dot) [dot] {dot} — mit optionalen Leerzeichen.
_OBF_DOT = r"(?:\(\s*(?:\.|dot)\s*\)|\[\s*(?:\.|dot)\s*\]|\{\s*(?:\.|dot)\s*\})"

#: http/https-Schema inkl. hxxp, Leerzeichen-Einschub und URL-Encoding (%68ttp, htt%70 …).
_SCHEME_HTTP = (
    r"(?:%68|h)\s{0,3}(?:%74|t|x)\s{0,3}(?:%74|t|x)\s{0,3}(?:%70|p)\s{0,3}(?:%73|s)?"
)
_SCHEME = rf"(?:{_SCHEME_HTTP}|f\s{{0,3}}t\s{{0,3}}p\s{{0,3}}s?)"
_SEP = r"\s{0,3}:\s{0,3}/\s{0,3}/\s{0,3}"

#: Ein Domain-Label; ``\w`` ist Unicode-fähig, damit Homoglyphen-Domains erkannt werden.
#:
#: Die Obergrenze ist bewusst **nicht** die DNS-Grenze von 63 Oktetten (HC-24): Eine Marke
#: mit 64 Zeichen ist zwar nicht auflösbar, wurde aber weder hier noch vom Nachbrenner
#: erkannt und lief mit lebenden Punkten durch. Die *Erkennung* ist großzügig (Deckel nur
#: ganz ohne Deckel); ob defangt wird, entscheidet die TLD-Formprüfung in
#: :func:`LinkCollector.scrub` bzw. `output.sanitizer._defang_domain_match` (ADR-036).
#: Backtracking ist unkritisch: Weder ``.`` noch die obfuskierten Punktformen liegen in
#: der Zeichenklasse, die Zerlegung in Marken ist also eindeutig.
_LABEL = r"[\w%-]+"

#: Zeichen, die niemals Teil eines Fundes sein dürfen: die intern gesetzten
#: ``\x00``-Platzhalter (HC-8). Ohne diesen Ausschluss schnitt z. B. ``_RE_MAILTO`` in ein
#: bereits gesetztes Token hinein, die Rück-Ersetzung fand es nicht mehr — und ein rohes
#: U+0000 erreichte die Zustellung.
_NUL = "\x00"

#: Punkt-Varianten zwischen Labels. Leerzeichen-Varianten verlangen ein
#: Kleinbuchstaben-/Ziffern-Lookahead, damit nach „example.com. Nächster Satz" nicht der
#: folgende Satz verschluckt wird (bewusster Trade-off, ADR-028).
_HOST_SEP = (
    rf"(?:{_OBF_DOT}|\.|(?:\s{{1,3}}(?:{_OBF_DOT}|\.)\s{{0,3}}|(?:{_OBF_DOT}|\.)\s{{1,3}})"
    r"(?=[a-z0-9]))"
)
_HOSTISH = rf"{_LABEL}(?:{_HOST_SEP}{_LABEL})*"
_PATH = r"(?:[/?#][^\s<>\"'()\x00]*)?"

_RE_URL = re.compile(
    rf"{_SCHEME}{_SEP}(?:[^\s<>\"'@/\x00]{{1,64}}@)?{_HOSTISH}(?::\d{{1,5}})?{_PATH}",
    re.IGNORECASE,
)
_RE_MAILTO = re.compile(r"mailto\s{0,3}:\s{0,3}[^\s<>\"'`,;:\x00]{1,128}", re.IGNORECASE)
_RE_TEL = re.compile(r"tel\s{0,3}:\s{0,3}\+?[0-9][0-9 ()./-]{2,24}[0-9]", re.IGNORECASE)
_RE_WWW = re.compile(
    rf"\bwww\s{{0,3}}(?:{_OBF_DOT}|\.)\s{{0,3}}{_HOSTISH}{_PATH}", re.IGNORECASE
)
_RE_OBF_DOMAIN = re.compile(
    rf"\b{_LABEL}(?:\s{{0,3}}{_OBF_DOT}\s{{0,3}}{_LABEL})+{_PATH}", re.IGNORECASE
)
_RE_BARE_DOMAIN = re.compile(
    rf"(?<![\w@.-]){_LABEL}(?:\.{_LABEL}){{1,10}}(?:/[^\s<>\"'()\x00]*)?", re.IGNORECASE
)

#: Satzzeichen, die am Ende eines Funds abgetrennt werden (gehören zum Satz, nicht zur URL).
_TRAILING_PUNCTUATION = ".,;:!?"

#: Markup-Zeichen, die aus der defangten Form fallen (HC-7). Deckungsgleich mit
#: `output.sanitizer._MARKUP_CHARS` **ohne** ``[``/``]``: Die eckigen Klammern tragen die
#: Defang-Token ``[.]``/``[:]``.
_MARKUP_STRIP = {ord(char): None for char in "`*|~\\"}

#: Ein gesetzter Platzhalter (``\x00<n>\x00``). Er wird zwischen den Erkennungs-Pässen
#: **atomar** übersprungen: Kein Pass darf in ein bereits gesetztes Token hineinschneiden
#: (HC-8) — sonst fände die Rück-Ersetzung es nicht mehr und ein rohes U+0000 bliebe stehen.
_RE_PLACEHOLDER = re.compile(r"\x00\d{1,6}\x00")

#: Kanonisches http-Schema auf bereits „kondensiertem" Text (ohne Leerzeichen).
_RE_CANON_HTTP = re.compile(
    r"^(?:%68|h)(?:%74|t|x)(?:%74|t|x)(?:%70|p)(?P<s>%73|s)?", re.IGNORECASE
)

#: Datei-Endungen, die im Nackte-Domain-Pass **nicht** als TLD gewertet werden
#: („rechnung.pdf" ist keine Domain). Bewusste Lücke: `.zip`/`.js` existieren auch als TLD —
#: ohne Schema sind solche Nennungen aber ohnehin nicht klickbar (I3), siehe ADR-028.
_FILE_EXTENSIONS = frozenset(
    {
        "exe", "dll", "msi", "bat", "cmd", "ps1", "sh", "js", "mjs", "py", "jar", "apk",
        "zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "iso", "img", "bin", "dat",
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "rtf",
        "txt", "csv", "md", "html", "htm", "eml", "ics", "vcf", "log", "ini", "cfg",
        "toml", "json", "xml", "yml", "yaml", "png", "jpg", "jpeg", "gif", "svg", "webp",
        "bmp", "tif", "tiff", "mp3", "mp4", "mov", "avi", "db", "sqlite", "bak", "tmp",
    }
)


def _sub_outside_placeholders(
    pattern: re.Pattern[str], repl: Callable[[re.Match[str]], str], text: str
) -> str:
    """Wendet `pattern` nur auf die Abschnitte **zwischen** gesetzten Platzhaltern an.

    Damit kann kein Erkennungs-Pass in ein Token eines früheren Passes hineinschneiden
    (HC-8) und auch kein Fund über ein Token hinweg zusammenwachsen. Die Zeichenklassen
    schließen ``\x00`` zusätzlich aus — diese Funktion ist die Regel, der Ausschluss die
    zweite Schicht.
    """
    if _NUL not in text:
        return pattern.sub(repl, text)
    chunks: list[str] = []
    position = 0
    for token in _RE_PLACEHOLDER.finditer(text):
        chunks.append(pattern.sub(repl, text[position : token.start()]))
        chunks.append(token.group(0))
        position = token.end()
    chunks.append(pattern.sub(repl, text[position:]))
    return "".join(chunks)


def _split_trailing(raw: str) -> tuple[str, str]:
    """Trennt Satz-Interpunktion am Ende eines Funds ab („… http://x.example." → Punkt bleibt)."""
    core = raw.rstrip(_TRAILING_PUNCTUATION)
    return core, raw[len(core) :]


def _condense(raw: str) -> str:
    """Entfernt Leerzeichen und ersetzt obfuskierte Punkte — Basis für die Analyse."""
    no_space = re.sub(r"\s+", "", raw)
    return re.sub(_OBF_DOT, ".", no_space, flags=re.IGNORECASE)


def _canonical_url(raw: str) -> str:
    """Baut aus einem (obfuskierten) Fund die kanonische URL-Form (http…://…)."""
    condensed = _condense(raw)
    match = _RE_CANON_HTTP.match(condensed)
    if match is not None:
        scheme = "https" if match.group("s") else "http"
        return scheme + condensed[match.end() :].lower()
    return condensed.lower()


def _host_of(url: str) -> str:
    """Extrahiert den Host: nach ``://``, hinter Userinfo (`@`-Trick), ohne Port."""
    after = url.split("://", 1)[1] if "://" in url else url
    authority = re.split(r"[/?#]", after, maxsplit=1)[0]
    host = authority.rsplit("@", 1)[-1]
    host = re.sub(r":\d+$", "", host)
    host = unquote(host).strip(".").lower()
    cleaned, _ = clean_text(host)
    # „www." im Marker würde von Messenger-Clients autoverlinkt — nur für die Anzeige
    # strippen (die defangte Vollform in `links_found` behält das Präfix).
    if cleaned.startswith("www.") and cleaned.count(".") >= 2:
        cleaned = cleaned[4:]
    return cleaned or "unknown"


def _defang(url: str) -> str:
    """Defangte Darstellung: ``hxxp``-Schema, ``[:]//``-Trenner, ``[.]``-Punkte, begrenzt.

    Auch der ``://``-Trenner und der ``mailto:``-Doppelpunkt werden gebrochen, damit die
    defangte Form nirgends (auch nicht in der optionalen Fußnote) einem Auto-Linkifier
    zum Opfer fallen kann (I3).

    Zusätzlich fallen die Messenger-Markup-Zeichen weg (HC-7). Der Eintrag ist ein vom
    Programm gebauter, inhaltlich aber **angreifergesteuerter** String: Er wandert als
    Link-Fußnote roh in die Nachricht, und `output.sanitizer.final_guard` enthält bewusst
    kein ``_RE_MARKUP`` (es fräße die eigenen Defang-Klammern, ADR-062). Ein unpaariges
    ```` ``` ```` in einer Query öffnete auf Discord sonst einen Codeblock, der alle
    folgenden Fußnotenzeilen verschluckt. ``[`` und ``]`` bleiben stehen — ohne sie
    zerfielen ``[.]`` und ``[:]``.
    """
    url = url.translate(_MARKUP_STRIP)
    defanged = re.sub(r"^https", "hxxps", url)
    defanged = re.sub(r"^http\b", "hxxp", defanged)
    defanged = re.sub(r"^ftp", "fxp", defanged)
    defanged = re.sub(r"^mailto:", "mailto[:]", defanged)
    defanged = defanged.replace("://", "[:]//")
    defanged = defanged.replace(".", "[.]")
    if len(defanged) > _MAX_DEFANGED_CHARS:
        defanged = defanged[:_MAX_DEFANGED_CHARS] + "…"
    return defanged


def _punycode_unicode(host: str) -> str | None:
    """Unicode-Darstellung einer ``xn--``-Domain, oder None wenn nicht dekodierbar."""
    if "xn--" not in host:
        return None
    try:
        decoded = host.encode("ascii").decode("idna")
    except (UnicodeError, UnicodeDecodeError):
        return None
    cleaned, _ = clean_text(decoded)
    return cleaned


@dataclass
class LinkCollector:
    """Sammelt Link-Funde über mehrere Textteile einer Mail (Body, Anhänge, Betreff).

    Ein Objekt pro Mail: Die Nummerierung `#n` läuft über alle Teile durch, damit ein
    Fußnoten-Eintrag eindeutig einem Marker zuordenbar ist.
    """

    links_removed: int = 0
    links_found: list[str] = field(default_factory=list)
    punycode_domains: list[str] = field(default_factory=list)
    mixed_script_domains: list[str] = field(default_factory=list)
    #: Mindestens ein Fund lag jenseits von :data:`MAX_LINKS_PER_MAIL` und wurde ohne
    #: Nummer und ohne Domain-Analyse entfernt (R-5). Der Composer sagt das dem Nutzer.
    links_capped: bool = False

    def scrub(self, text: str) -> str:
        """Ersetzt alle erkannten URLs/Adressen in `text` durch Marker und protokolliert sie."""
        placeholders: dict[str, str] = {}

        def stash(marker: str) -> str:
            token = f"\x00{len(placeholders)}\x00"
            placeholders[token] = marker
            return token

        def replace_url(match: re.Match[str]) -> str:
            core, tail = _split_trailing(match.group(0))
            url = _canonical_url(core)
            host = _host_of(url)
            return stash(self._record(host, _defang(url))) + tail

        def replace_mailto(match: re.Match[str]) -> str:
            core, tail = _split_trailing(match.group(0))
            address = _condense(core).split(":", 1)[-1].lower()
            host = address.rsplit("@", 1)[-1] if "@" in address else "unknown"
            cleaned_host, _ = clean_text(host)
            marker = self._record(
                cleaned_host or "unknown", _defang(f"mailto:{address}"), kind="Mail"
            )
            return stash(marker) + tail

        def replace_tel(match: re.Match[str]) -> str:
            number = _condense(match.group(0)).split(":", 1)[-1]
            self.links_removed += 1
            index = self.links_removed
            if index > MAX_LINKS_PER_MAIL:
                self.links_capped = True
                return stash(CAPPED_MARKER)
            if len(self.links_found) < _MAX_LINKS_LISTED:
                self.links_found.append(f"#{index}: tel[:]{number}")
            return stash(f"[Tel #{index}]")

        def replace_domain(match: re.Match[str]) -> str:
            core, tail = _split_trailing(match.group(0))
            condensed = _condense(core).lower()
            host = _host_of(condensed)
            return stash(self._record(host, _defang(condensed))) + tail

        def replace_bare(match: re.Match[str]) -> str:
            core, tail = _split_trailing(match.group(0))
            condensed = _condense(core).lower()
            host = _host_of(condensed)
            labels = host.split(".")
            tld = labels[-1] if labels else ""
            has_path = any(sep in condensed for sep in "/?#")
            if len(tld) < 2 or not tld.isalpha():
                return match.group(0)
            if not has_path and tld in _FILE_EXTENSIONS:
                return match.group(0)
            return stash(self._record(host, _defang(condensed))) + tail

        text = _sub_outside_placeholders(_RE_URL, replace_url, text)
        text = _sub_outside_placeholders(_RE_MAILTO, replace_mailto, text)
        text = _sub_outside_placeholders(_RE_TEL, replace_tel, text)
        text = _sub_outside_placeholders(_RE_WWW, replace_domain, text)
        text = _sub_outside_placeholders(_RE_OBF_DOMAIN, replace_domain, text)
        text = _sub_outside_placeholders(_RE_BARE_DOMAIN, replace_bare, text)

        # Ein einziger Durchlauf statt eines Voll-Scans je Platzhalter (R-5): die alte
        # Schleife war O(Funde mal Textlänge) und kostete bei 32 000 Links 17 s.
        if placeholders:
            text = _RE_PLACEHOLDER.sub(
                lambda match: placeholders.get(match.group(0), ""), text
            )
        # Zusicherung statt Vertrauen (HC-8): Kein Platzhalter-Byte verlässt das Modul,
        # auch wenn ein künftiger Pass die atomare Regel verletzt. Ein übrig gebliebenes
        # U+0000 wäre ein Steuerzeichen in der Zustellung — fail-safe entfernen.
        return text.replace(_NUL, "")

    def _record(self, host: str, defanged: str, *, kind: str = "Link") -> str:
        """Zählt einen Fund, prüft Punycode/Mixed-Script und liefert den Text-Marker."""
        self.links_removed += 1
        index = self.links_removed
        if index > MAX_LINKS_PER_MAIL:
            # Jenseits des Budgets: entfernt wird trotzdem (I3), nur nicht mehr benannt.
            self.links_capped = True
            return CAPPED_MARKER
        if len(self.links_found) < _MAX_LINKS_LISTED:
            self.links_found.append(f"#{index}: {defanged}")

        suffix = ""
        unicode_form = _punycode_unicode(host)
        if "xn--" in host:
            suffix = " (caution: punycode)"
            entry = host.replace(".", "[.]")
            if unicode_form:
                entry += f" (Unicode: {unicode_form.replace('.', '[.]')})"
            if entry not in self.punycode_domains:
                self.punycode_domains.append(entry)

        checked = unicode_form or host
        if is_mixed_script_domain(checked):
            entry = checked.replace(".", "[.]")
            if entry not in self.mixed_script_domains:
                self.mixed_script_domains.append(entry)
            suffix += " (caution: mixed writing systems)"

        return f"[{kind} #{index}: {host}{suffix}]"


def build_footnote(links_found: list[str]) -> str:
    """Baut die defangte Link-Fußnote für die zugestellte Nachricht (`links.footnote`).

    Die Einträge stammen aus :attr:`LinkCollector.links_found` und sind bereits defanged
    (`hxxps[:]//ziel[.]example/…`) — die Fußnote enthält also kein klickbares Ziel (I3).
    Der Composer hängt sie an; im LLM-Prompt hat sie nichts verloren (CT-14, ADR-072).

    Args:
        links_found: Die defangten Einträge in Fundreihenfolge.

    Returns:
        Der mehrzeilige Fußnotenblock ohne führende Leerzeile, oder `""` ohne Einträge.
    """
    if not links_found:
        return ""
    lines = [FOOTNOTE_TITLE]
    total = 0
    for entry in links_found:
        total += len(entry) + 1
        if total > _MAX_FOOTNOTE_CHARS:
            lines.append("[further links suppressed]")
            break
        lines.append(entry)
    return "\n".join(lines)
